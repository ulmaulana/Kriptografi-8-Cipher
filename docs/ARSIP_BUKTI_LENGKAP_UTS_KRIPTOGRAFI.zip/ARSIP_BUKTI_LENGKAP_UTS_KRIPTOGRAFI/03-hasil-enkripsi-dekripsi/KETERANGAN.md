# Hasil enkripsi dan dekripsi

| Folder | Isi |
| --- | --- |
| `skrip-bukti/<cipher>/<file>.dat` | Paket terenkripsi dari 35 skenario file yang dijalankan `pnpm evidence` |
| `skrip-bukti/<cipher>/pulih-<file>` | File hasil dekripsi paket yang dibaca ulang dari disk |
| `skrip-bukti/teks/<cipher>.dat` | Paket contoh pesan teks untuk tiap cipher |
| `antarmuka/file-utuh/<cipher>/<file>.dat` | Paket yang diunduh dari antarmuka web pada uji 35 skenario |
| `antarmuka/file-utuh/<cipher>/pulih/<file>` | File yang diunduh dari antarmuka setelah halaman dimuat ulang dan paket didekripsi |
| `antarmuka/file-teks-alfabet/<cipher>/` | Paket dan hasil dekripsi pilihan Isi sebagai teks alfabet untuk `teks-contoh.txt` |

Nama `<cipher>` adalah `vigenere`, `autokey`, `extended-vigenere`, `playfair`, `affine`, `hill`, atau `super`. File `.dat` tidak dapat dibuka langsung oleh program asalnya karena header file ikut terenkripsi. File hasil dekripsi identik byte demi byte dengan file di folder `02-contoh-file`.
