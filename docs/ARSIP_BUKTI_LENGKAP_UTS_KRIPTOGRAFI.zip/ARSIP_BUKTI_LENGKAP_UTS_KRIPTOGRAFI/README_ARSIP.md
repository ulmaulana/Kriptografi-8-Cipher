# Arsip Bukti Lengkap UTS Kriptografi

Arsip ini menyimpan bukti pendukung untuk dokumen `00-BAHAN_LAPORAN_UTS_KRIPTOGRAFI.md`. Berkas di arsip ini tidak perlu diunggah saat menyusun laporan. Dokumen bahan laporan, lampiran kode program, dan 17 gambar laporan ada di folder `docs/BAHAN_LAPORAN_UTS_KRIPTOGRAFI`.

| Folder | Isi |
| --- | --- |
| `01-screenshot-asli/` | 40 screenshot asli dan keterangannya |
| `02-contoh-file/` | Lima file contoh: teks, gambar PNG, database SQLite, audio WAV, dan video WebM |
| `03-hasil-enkripsi-dekripsi/` | Paket `.dat` dan file hasil dekripsi dari skrip bukti dan dari antarmuka web |
| `04-hasil-pengujian/` | Ringkasan pengujian, data hasil dalam JSON, log setiap perintah, dan skrip uji tambahan |
| `05-kode-program/` | Salinan kode program lengkap dengan README, konfigurasi, lockfile, pengujian, skrip, dan file contoh. Jalankan `pnpm install` lalu `pnpm dev` dari folder ini |
