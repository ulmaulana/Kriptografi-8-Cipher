# Keterangan Screenshot

Folder ini memuat 40 screenshot asli dari aplikasi yang berjalan dengan build produksi di Chromium pada 1 Oktober 2026, dengan lebar tangkapan desktop 1440 piksel dan halaman penuh. Sebanyak 39 screenshot dibuat oleh pengujian browser `pnpm test:e2e`, dan `tambahan-file-teks-alfabet-vigenere.png` dibuat oleh uji tambahan. Gambar laporan bernomor 1 sampai 17 pada dokumen bahan laporan disusun dari sebagian screenshot ini.

## Tampilan umum

**`01-tampilan-utama.png`**. Tampilan awal aplikasi dengan tema gelap. Tab Beranda memuat enam panel bernomor: daftar tujuh cipher dan detail Vigenere standar, pilihan Enkripsi atau Dekripsi, pilihan Teks atau File, kolom pesan, kolom kata kunci, dan panel hasil berstatus Menunggu. Lencana di kanan atas menyatakan proses lokal tanpa unggahan ke server.

**`02-tema-terang.png`**. Tampilan awal yang sama setelah tombol Mode terang ditekan. Tombol di ujung kanan baris tab berubah menjadi Mode gelap.

**`03-tema-terang-hasil.png`**. Setelah halaman dimuat ulang, tema terang tetap dipakai. Enkripsi Vigenere `attack at dawn` dengan kunci LEMON menampilkan plainteks setelah normalisasi `ATTACKATDAWN`, cipherteks huruf `LXFOPVEFRNHR`, cipherteks Base64 `TFhGT1BWRUZSTkhS`, dan paket berukuran 271 byte.

**`info-super-enkripsi.png`**. Keterangan "Gabungan Extended Vigenere Cipher dan cipher transposisi (metode kolom)" muncul saat ikon info di samping Super Enkripsi disorot. Cipher yang terpilih tetap Vigenere standar.

## Pesan yang diketik pada tujuh cipher

**`teks-vigenere-enkripsi.png`**. Enkripsi Vigenere standar. Pesan `attack at dawn` dinormalisasi menjadi 12 huruf `ATTACKATDAWN`, dan kunci `lemon` dinormalisasi menjadi LEMON. Cipherteks huruf `LXFOPVEFRNHR` ditampilkan kapital tanpa spasi, dan cipherteks Base64 `TFhGT1BWRUZSTkhS` ditampilkan apa adanya. Detail cipher menandai huruf kunci pertama L dengan geser 11.

**`teks-vigenere-dekripsi.png`**. Paket `cipherteks-vigenere.dat` diunggah pada konteks browser baru. Algoritma terisi otomatis dari paket. Dengan kunci lemon, status menyatakan pemulihan berhasil dengan ukuran 12 byte dan SHA-256 cocok, dan plainteks huruf `ATTACKATDAWN` tampil dengan nama unduhan `plainteks-vigenere.txt`.

**`teks-autokey-enkripsi.png`**. Enkripsi Auto-Key Vigenere. Pesan `ATTACK AT DAWN` dengan primer QUEENLY menghasilkan cipherteks huruf `QNXEPVYTWTWP` dan cipherteks Base64 `UU5YRVBWWVRXVFdQ`.

**`teks-autokey-dekripsi.png`**. Dekripsi paket Auto-Key pada konteks browser baru dengan primer QUEENLY. Pemulihan berhasil, ukuran 12 byte dan SHA-256 cocok, dan plainteks `ATTACKATDAWN` kembali.

**`teks-extended-vigenere-enkripsi.png`**. Enkripsi Extended Vigenere. Pesan `Halo` diproses sebagai 4 byte UTF-8 dengan kunci heksadesimal `01 02`. Plainteks Base64 `SGFsbw==` dan cipherteks Base64 `SWNtcQ==` ditampilkan, tanpa cipherteks huruf karena cipher ini bekerja pada byte.

**`teks-extended-vigenere-dekripsi.png`**. Dekripsi paket Extended Vigenere pada konteks browser baru. Pemulihan berhasil dengan ukuran 4 byte dan SHA-256 cocok, dan plainteks UTF-8 `Halo` kembali.

**`teks-playfair-enkripsi.png`**. Enkripsi Playfair dengan kunci PLAYFAIREXAMPLE. Matriks 5 x 5 `P L A Y F / I R E X M / B C D G H / K N O Q S / T U V W Z` tampil di panel kunci. Catatan hasil menyebut satu huruf pengisi disisipkan dan nol J digabung. Plainteks 25 huruf `HIDETHEGOLDINTHETREESTUMP` menjadi cipherteks 26 huruf `BMODZBXDNABEKUDMUIXMMOUVIF`, dan paket berukuran 386 byte.

**`teks-playfair-dekripsi.png`**. Dekripsi paket Playfair pada konteks browser baru. Catatan menyebut satu pengisi dibuang sesuai metadata dan nol J dipulihkan. Plainteks `HIDETHEGOLDINTHETREESTUMP` kembali tanpa X sisipan, dengan ukuran 25 byte dan SHA-256 cocok.

**`teks-affine-enkripsi.png`**. Enkripsi Affine dengan a = 5 dan b = 8. Detail cipher menunjukkan A menjadi I. Plainteks `AFFINECIPHER` menjadi cipherteks huruf `IHHWVCSWFRCP`.

**`teks-affine-dekripsi.png`**. Dekripsi paket Affine pada konteks browser baru. Pemulihan berhasil dengan ukuran 12 byte, dan plainteks `AFFINECIPHER` kembali.

**`teks-hill-enkripsi.png`**. Enkripsi Hill dengan matriks 3 x 3 `[[6,24,1],[13,16,10],[20,17,15]]`. Catatan menampilkan determinan modulo 26 = 25, invers modulo 26 `[[8,5,10],[21,8,21],[21,12,8]]`, dan padding 0 huruf. Plainteks `ACT` menjadi `POH`.

**`teks-hill-dekripsi.png`**. Dekripsi paket Hill pada konteks browser baru. Catatan menyebut padding X dibuang sesuai metadata sebanyak 0. Plainteks `ACT` kembali dengan ukuran 3 byte dan SHA-256 cocok.

**`teks-super-enkripsi.png`**. Super Enkripsi pesan `ABCDEFG` dengan kunci byte heksadesimal `01 02` dan kata kunci kolom BABA. Cipherteks Base64 yang dihasilkan adalah `REhGQkZESA==`, dan paket berukuran 247 byte.

**`teks-super-dekripsi.png`**. Dekripsi paket Super Enkripsi pada konteks browser baru. Pemulihan berhasil dengan ukuran 7 byte dan SHA-256 cocok, dan plainteks `ABCDEFG` kembali.

## File pada lima kategori

**`file-vigenere-enkripsi.png`**. Enkripsi file teks `teks-contoh.txt` (263 byte, `text/plain`) dengan Vigenere dan kunci KRIPTOGRAFI pada mode File utuh. Catatan menyebut codec alpha25-v1 mengubah 263 byte menjadi 526 huruf sebelum cipher. Cipherteks huruf berisi 526 huruf, dan paket berukuran 838 byte.

**`file-vigenere-dekripsi.png`**. Dekripsi `teks-contoh.txt.dat` pada konteks browser baru. Panel paket menampilkan mode File utuh dan file asal `teks-contoh.txt`. Hasil dekripsi file teks mengembalikan 263 byte dengan SHA-256 `d13859ef...163f68`, sama dengan file asal, dan tombol unduh memakai nama `teks-contoh.txt`.

**`file-autokey-enkripsi.png`**. Enkripsi gambar `gambar-contoh.png` (13.519 byte, `image/png`) dengan Auto-Key dan primer UTSKRIPTO. Codec mengubah 13.519 byte menjadi 27.038 huruf. Pratinjau keluaran panjang dibatasi 4.000 karakter dengan keterangan bahwa salin dan unduh memuat data lengkap. Paket berukuran 27.354 byte.

**`file-autokey-dekripsi.png`**. Hasil dekripsi gambar mengembalikan ukuran 13.519 byte dan SHA-256 `c2cd2cf0...1feec7` yang sama dengan gambar asal. File siap diunduh sebagai `gambar-contoh.png`.

**`file-extended-vigenere-enkripsi.png`**. Enkripsi database `database-contoh.sqlite` (20.480 byte) dengan Extended Vigenere dan kunci teks `Kunci Byte 2026!` (16 byte UTF-8). Seluruh byte termasuk header dienkripsi langsung sebagai byte, dan paket berukuran 20.792 byte. Jenis file tertulis tidak diketahui karena browser tidak memberi tipe MIME untuk ekstensi `.sqlite`.

**`file-extended-vigenere-dekripsi.png`**. Hasil dekripsi database mengembalikan 20.480 byte dengan SHA-256 `c7676535...358669` yang sama dengan database asal, dan nama unduhan `database-contoh.sqlite`.

**`file-playfair-enkripsi.png`**. Enkripsi audio `audio-contoh.wav` (16.044 byte, `audio/wav`) dengan Playfair dan kunci MONARCHY. Matriks `M O N A R / C H Y B D / E F G I K / L P Q S T / U V W X Z` tampil di panel kunci. Codec menghasilkan 32.088 huruf, 1.178 huruf pengisi disisipkan, cipherteks berisi 33.266 huruf, dan paket berukuran 39.211 byte.

**`file-playfair-dekripsi.png`**. Dekripsi audio pada konteks browser baru. Catatan menyebut 1.178 pengisi dibuang sesuai metadata dan 32.088 huruf dikembalikan menjadi 16.044 byte. SHA-256 hasil `b5d248ce...095c46` sama dengan audio asal.

**`file-affine-enkripsi.png`**. Enkripsi video `video-contoh.webm` (43.791 byte, `video/webm`) dengan Affine a = 7 dan b = 10. Codec menghasilkan 87.582 huruf, dan paket berukuran 87.898 byte. Cipherteks huruf memperlihatkan pola berulang seperti `JTJTJT`.

**`file-affine-dekripsi.png`**. Hasil dekripsi video dengan Affine mengembalikan 43.791 byte dengan SHA-256 `e5400629...8366ed` yang sama dengan video asal, dan nama unduhan `video-contoh.webm`.

**`file-hill-enkripsi.png`**. Enkripsi gambar `gambar-contoh.png` dengan Hill dan matriks 2 x 2 `[[3,3],[2,5]]`. Catatan menampilkan determinan modulo 26 = 9, invers `[[15,17],[20,9]]`, codec 13.519 byte menjadi 27.038 huruf, dan padding 0 huruf. Paket berukuran 27.379 byte.

**`file-hill-dekripsi.png`**. Hasil dekripsi gambar dengan Hill mengembalikan 13.519 byte dengan SHA-256 `c2cd2cf0...1feec7` yang sama dengan gambar asal.

**`file-super-enkripsi.png`**. Super Enkripsi video `video-contoh.webm` dengan kunci byte `SuperKunci` (10 byte UTF-8) dan kata kunci kolom TRANSPOSISI. Seluruh byte termasuk header dienkripsi langsung, dan paket berukuran 44.096 byte.

**`file-super-dekripsi.png`**. Hasil dekripsi video dengan Super Enkripsi mengembalikan 43.791 byte dengan SHA-256 `e5400629...8366ed` yang sama dengan video asal.

## Validasi dan jalur khusus

**`validasi-affine.png`**. Kunci Affine a = 2 ditolak. Pesan di bawah kolom Nilai a menyatakan a = 2 tidak relatif prima terhadap 26 dan menyebutkan nilai a yang valid. Panel hasil tetap Menunggu sehingga tidak ada cipherteks yang dibuat.

**`validasi-hill.png`**. Matriks Hill `[[2,4],[1,2]]` ditolak dengan pesan determinan modulo 26 = 0, tidak relatif prima terhadap 26 sehingga matriks tidak mempunyai invers.

**`validasi-kunci-salah.png`**. Paket Vigenere yang dibuat dengan kunci LEMON didekripsi dengan kunci LIME. Status berubah menjadi Gagal dengan pesan bahwa checksum SHA-256 tidak cocok sehingga pemulihan tidak dinyatakan berhasil, dan tidak ada plainteks yang ditampilkan.

**`dekripsi-mentah-playfair.png`**. Format Cipherteks huruf mentah dengan masukan `BMODZBXDNABEKUDMUIXMMOUVIF` dan kunci PLAYFAIREXAMPLE. Hasilnya `HIDETHEGOLDINTHETREXESTUMP` yang masih memuat X pengisi, dan status menyatakan tidak ada checksum untuk memverifikasi hasil.

**`dekripsi-base64-payload.png`**. Super Enkripsi didekripsi dari Cipherteks Base64 (payload saja) dengan kunci byte `Kunci+/=` dan kata kunci kolom ZEBRA. Plainteks `Data rahasia 2026 + / = ✓` kembali utuh, termasuk angka dan simbol.

**`hasil-lama-ditandai.png`**. Setelah enkripsi, kata kunci diubah dari LEMON menjadi LEMONADE. Panel hasil berstatus Hasil lama dengan peringatan bahwa masukan atau kunci berubah sejak proses terakhir, dan hasil sebelumnya ditampilkan redup.

**`layar-sempit.png`**. Tampilan pada lebar 390 piksel. Semua panel tersusun satu kolom tanpa gulir horizontal pada halaman. Enkripsi Hill pesan `Serang pukul 10.30! Kirim bantuan ke gerbang timur secepatnya.` menghasilkan 47 huruf setelah normalisasi, satu huruf padding, dan cipherteks 48 huruf. Label tab Tentang pada baris tab terlihat terpotong (lihat bagian 8.4 dokumen bahan laporan).

**`tambahan-file-teks-alfabet-vigenere.png`**. File `teks-contoh.txt` dienkripsi dengan Vigenere menggunakan pilihan Isi sebagai teks alfabet. Panel hasil menampilkan 151 huruf hasil normalisasi isi file, cipherteks huruf 151 huruf, dan paket berukuran 447 byte.
