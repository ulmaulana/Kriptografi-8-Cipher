// Uji tambahan bahan laporan: 7 cipher x 5 fixture melalui antarmuka web.
// Setiap skenario mengenkripsi file di browser, mengunduh paket .dat, memuat
// ulang halaman, mengunggah paket hasil unduhan, mendekripsi dengan kunci yang
// diketik ulang, mengunduh file pemulihan, lalu membandingkan byte, ukuran, dan
// SHA-256 dengan file asal. Checksum dihitung dengan node:crypto.
//
// Pemakaian (server aplikasi harus sudah berjalan, misalnya `pnpm start -p 3200`):
//   node ui-roundtrip-35.mjs <folder proyek> <folder keluaran> [baseURL]

import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";

const [projectDir, outDir, baseURL = "http://127.0.0.1:3200"] = process.argv.slice(2);
if (!projectDir || !outDir) {
  console.error("Pemakaian: node ui-roundtrip-35.mjs <folder proyek> <folder keluaran> [baseURL]");
  process.exit(2);
}
const require = createRequire(path.join(path.resolve(projectDir), "package.json"));
const { chromium } = require("@playwright/test");

const CIPHERS = ["vigenere", "autokey", "extended-vigenere", "playfair", "affine", "hill", "super"];
const NAMES = {
  vigenere: "Vigenere standar",
  autokey: "Auto-Key Vigenere",
  "extended-vigenere": "Extended Vigenere",
  playfair: "Playfair",
  affine: "Affine",
  hill: "Hill",
  super: "Super Enkripsi",
};
const FIXTURES = [
  { file: "teks-contoh.txt", kind: "Teks" },
  { file: "gambar-contoh.png", kind: "Gambar" },
  { file: "database-contoh.sqlite", kind: "Database" },
  { file: "audio-contoh.wav", kind: "Audio" },
  { file: "video-contoh.webm", kind: "Video" },
];
// Sama dengan TEST_KEYS di tests/unit/helpers.ts sehingga payload dapat
// dibandingkan dengan paket hasil `pnpm evidence`.
const KEYS = {
  vigenere: { keyword: "KRIPTOGRAFI" },
  autokey: { keyword: "UTSKRIPTO" },
  "extended-vigenere": { byteKey: "Kunci Byte 2026!" },
  playfair: { keyword: "MONARCHY" },
  affine: { a: "7", b: "10" },
  hill: { matrix: "6 24 1\n13 16 10\n20 17 15" },
  super: { byteKey: "SuperKunci", columnKey: "TRANSPOSISI" },
};

const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");

function parseContainer(buf) {
  const magic = buf.subarray(0, 8).toString("latin1");
  const version = buf[8];
  const metaLength = buf.readUInt32BE(9);
  const metaJson = buf.subarray(13, 13 + metaLength).toString("utf8");
  return { magic, version, metaJson, metadata: JSON.parse(metaJson), payload: buf.subarray(13 + metaLength) };
}

async function selectCipher(page, cipher) {
  await page.locator(`label.cipher-option:has(input[value="${cipher}"])`).click();
}

async function selectOperation(page, op) {
  await page.locator(".segmented label", { hasText: new RegExp(`^${op}$`) }).click();
}

async function fillKeys(page, key) {
  if (key.keyword !== undefined) await page.locator("#key-keyword").fill(key.keyword);
  if (key.byteKey !== undefined) {
    await page.locator(".segmented label", { hasText: "Teks UTF-8" }).click();
    await page.locator("#key-byte").fill(key.byteKey);
  }
  if (key.columnKey !== undefined) await page.locator("#key-column").fill(key.columnKey);
  if (key.a !== undefined) await page.locator("#key-a").fill(key.a);
  if (key.b !== undefined) await page.locator("#key-b").fill(key.b);
  if (key.matrix !== undefined) await page.locator("#key-hill").fill(key.matrix);
}

async function download(page, testId, dir) {
  const [dl] = await Promise.all([page.waitForEvent("download"), page.getByTestId(testId).click()]);
  const target = path.join(dir, dl.suggestedFilename());
  await dl.saveAs(target);
  return { path: target, name: dl.suggestedFilename() };
}

const browser = await chromium.launch();
const browserVersion = browser.version();
const results = [];
try {
  for (const cipher of CIPHERS) {
    for (const fx of FIXTURES) {
      const key = KEYS[cipher];
      const fixturePath = path.join(projectDir, "fixtures", fx.file);
      const original = readFileSync(fixturePath);
      const dir = path.join(outDir, "ui-roundtrip", cipher);
      mkdirSync(path.join(dir, "pulih"), { recursive: true });
      const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1000 } });
      const page = await context.newPage();
      const row = { no: results.length + 1, algorithm: cipher, algorithmName: NAMES[cipher], fileKind: fx.kind, fixture: fx.file };
      try {
        // 1. Enkripsi file utuh melalui antarmuka.
        await page.goto(baseURL);
        await selectCipher(page, cipher);
        await page.locator(".segmented label", { hasText: /^File$/ }).click();
        await page.locator("#enc-file").setInputFiles(fixturePath);
        await fillKeys(page, key);
        await page.getByTestId("run").click();
        await page.getByTestId("encrypt-result").waitFor({ timeout: 60_000 });
        const pkg = await download(page, "download-package", dir);
        const pkgBytes = readFileSync(pkg.path);
        const parsed = parseContainer(pkgBytes);

        // 2. Muat ulang halaman. State React hilang sehingga dekripsi hanya
        //    memakai paket hasil unduhan dan kunci yang diketik ulang.
        await page.reload();
        const staleResult = await page.getByTestId("encrypt-result").count();
        await selectOperation(page, "Dekripsi");
        await page.locator("#pkg-file").setInputFiles(pkg.path);
        await page.getByTestId("package-info").waitFor();
        const autoSelected = await page.locator(`input[name=cipher][value="${cipher}"]`).isChecked();
        await fillKeys(page, key);
        await page.getByTestId("run").click();
        const status = page.getByTestId("decrypt-status");
        await status.waitFor({ timeout: 60_000 });
        const statusText = (await status.innerText()).trim();
        const shownSha = (await page.getByTestId("decrypted-sha256").innerText()).trim();
        const restored = await download(page, "download-decrypted", path.join(dir, "pulih"));
        const restoredBytes = readFileSync(restored.path);

        // 3. Pembandingan dengan file asal dan dengan paket hasil `pnpm evidence`.
        const evidencePkg = parseContainer(readFileSync(path.join(projectDir, "evidence", "samples", cipher, `${fx.file}.dat`)));
        const keyStrings = [key.keyword, key.byteKey, key.columnKey].filter(Boolean);
        Object.assign(row, {
          packageName: pkg.name,
          packageMagic: parsed.magic,
          packageVersion: parsed.version,
          codec: parsed.metadata.codec,
          metadataFileName: parsed.metadata.file?.name ?? null,
          originalSize: original.length,
          packageSize: pkgBytes.length,
          payloadSize: parsed.payload.length,
          restoredName: restored.name,
          restoredSize: restoredBytes.length,
          originalSha256: sha256(original),
          restoredSha256: sha256(restoredBytes),
          shownSha256: shownSha,
          byteIdentical: restoredBytes.equals(original),
          headerHiddenInPayload: parsed.payload.indexOf(original.subarray(0, 16)) === -1,
          keyAbsentFromMetadata: keyStrings.every((k) => !parsed.metaJson.includes(k)),
          payloadMatchesEvidence: Buffer.compare(parsed.payload, evidencePkg.payload) === 0,
          stateClearedAfterReload: staleResult === 0,
          algorithmFromPackage: autoSelected,
          status: statusText,
        });
        row.result =
          row.byteIdentical &&
          row.restoredSha256 === row.originalSha256 &&
          row.shownSha256 === row.originalSha256 &&
          row.restoredName === fx.file &&
          row.headerHiddenInPayload &&
          row.keyAbsentFromMetadata &&
          row.stateClearedAfterReload &&
          row.algorithmFromPackage &&
          statusText.startsWith("Pemulihan berhasil")
            ? "LULUS"
            : "GAGAL";
      } catch (err) {
        row.result = "GAGAL";
        row.error = err instanceof Error ? err.message : String(err);
      }
      results.push(row);
      console.log(`${row.no}. ${cipher} ${fx.file}: ${row.result}${row.error ? ` (${row.error})` : ""}`);
      await context.close();
    }
  }
} finally {
  await browser.close();
}

const summary = CIPHERS.map((c) => {
  const rows = results.filter((r) => r.algorithm === c);
  return { algorithm: c, algorithmName: NAMES[c], scenarios: rows.length, passed: rows.filter((r) => r.result === "LULUS").length };
});
const out = {
  generatedAt: new Date().toISOString(),
  command: `node ui-roundtrip-35.mjs <proyek> <keluaran> ${baseURL}`,
  node: process.version,
  browser: `Chromium ${browserVersion}`,
  total: results.length,
  passed: results.filter((r) => r.result === "LULUS").length,
  summary,
  scenarios: results,
};
writeFileSync(path.join(outDir, "ui-roundtrip-35.json"), `${JSON.stringify(out, null, 2)}\n`);
console.log(`Selesai: ${out.passed}/${out.total} LULUS`);
if (out.passed !== out.total) process.exit(1);
