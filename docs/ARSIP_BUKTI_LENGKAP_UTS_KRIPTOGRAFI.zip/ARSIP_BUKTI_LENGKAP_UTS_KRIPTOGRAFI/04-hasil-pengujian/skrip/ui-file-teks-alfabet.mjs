// Uji tambahan bahan laporan: pilihan "Isi sebagai teks alfabet" pada mode File
// untuk lima cipher alfabet. File teks dienkripsi lewat antarmuka, paket diunduh,
// halaman dimuat ulang, lalu paket didekripsi. Hasil dibandingkan dengan huruf
// A-Z dari isi file yang dihitung terpisah di skrip ini.
//
// Pemakaian (server aplikasi harus sudah berjalan):
//   node ui-file-teks-alfabet.mjs <folder proyek> <folder keluaran> [baseURL]

import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";

const [projectDir, outDir, baseURL = "http://127.0.0.1:3200"] = process.argv.slice(2);
if (!projectDir || !outDir) {
  console.error("Pemakaian: node ui-file-teks-alfabet.mjs <folder proyek> <folder keluaran> [baseURL]");
  process.exit(2);
}
const require = createRequire(path.join(path.resolve(projectDir), "package.json"));
const { chromium } = require("@playwright/test");

const FIXTURE = "teks-contoh.txt";
const CASES = [
  { cipher: "vigenere", key: { keyword: "KRIPTOGRAFI" } },
  { cipher: "autokey", key: { keyword: "UTSKRIPTO" } },
  { cipher: "playfair", key: { keyword: "MONARCHY" } },
  { cipher: "affine", key: { a: "7", b: "10" } },
  { cipher: "hill", key: { matrix: "6 24 1\n13 16 10\n20 17 15" } },
];

const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function fillKeys(page, key) {
  if (key.keyword !== undefined) await page.locator("#key-keyword").fill(key.keyword);
  if (key.a !== undefined) await page.locator("#key-a").fill(key.a);
  if (key.b !== undefined) await page.locator("#key-b").fill(key.b);
  if (key.matrix !== undefined) await page.locator("#key-hill").fill(key.matrix);
}

async function download(page, testId, dir) {
  const [dl] = await Promise.all([page.waitForEvent("download"), page.getByTestId(testId).click()]);
  const target = path.join(dir, dl.suggestedFilename());
  await dl.saveAs(target);
  return { path: target, name: dl.suggestedFilename() };
}

const fixturePath = path.join(projectDir, "fixtures", FIXTURE);
const source = readFileSync(fixturePath);
// Huruf ASCII disaring lebih dulu lalu dijadikan kapital, tanpa memakai kode aplikasi.
const expected = source.toString("utf8").replace(/[^A-Za-z]/g, "").toUpperCase();

const browser = await chromium.launch();
const browserVersion = browser.version();
const results = [];
try {
  for (const tc of CASES) {
    const dir = path.join(outDir, "ui-file-teks-alfabet", tc.cipher);
    mkdirSync(dir, { recursive: true });
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    const row = { cipher: tc.cipher, fixture: FIXTURE, expectedLetters: expected.length };
    try {
      await page.goto(baseURL);
      await page.locator(`label.cipher-option:has(input[value="${tc.cipher}"])`).click();
      await page.locator(".segmented label", { hasText: /^File$/ }).click();
      await page.locator("#enc-file").setInputFiles(fixturePath);
      await page.locator("label", { hasText: "Isi sebagai teks alfabet" }).click();
      await fillKeys(page, tc.key);
      await page.getByTestId("run").click();
      await page.getByTestId("encrypt-result").waitFor({ timeout: 60_000 });
      const cipherLetters = (await page.getByTestId("out-cipher-letters").innerText()).trim();
      if (tc.cipher === "vigenere") {
        await page.screenshot({ path: path.join(outDir, "tambahan-file-teks-alfabet-vigenere.png"), fullPage: true });
      }
      const pkg = await download(page, "download-package", dir);
      const buf = readFileSync(pkg.path);
      const metaLength = buf.readUInt32BE(9);
      const meta = JSON.parse(buf.subarray(13, 13 + metaLength).toString("utf8"));

      await page.reload();
      await page.locator(".segmented label", { hasText: /^Dekripsi$/ }).click();
      await page.locator("#pkg-file").setInputFiles(pkg.path);
      await page.getByTestId("package-info").waitFor();
      await fillKeys(page, tc.key);
      await page.getByTestId("run").click();
      await page.getByTestId("decrypt-status").waitFor({ timeout: 60_000 });
      const status = (await page.getByTestId("decrypt-status").innerText()).trim();
      const shown = (await page.getByTestId("out-decrypted").innerText()).trim();
      const restored = await download(page, "download-decrypted", dir);
      const restoredText = readFileSync(restored.path, "utf8");

      Object.assign(row, {
        packageName: pkg.name,
        inputMode: meta.inputMode,
        codec: meta.codec,
        sourceFileName: meta.sourceFileName ?? null,
        hasFileMetadata: meta.file !== undefined,
        cipherLetters: cipherLetters.length,
        restoredName: restored.name,
        restoredLetters: restoredText.length,
        restoredSha256: sha256(Buffer.from(restoredText)),
        expectedSha256: sha256(Buffer.from(expected)),
        matchesExpected: restoredText === expected && shown === expected,
        status,
      });
      row.result =
        row.matchesExpected && meta.inputMode === "text" && meta.codec === "alpha-text-v1" && status.startsWith("Pemulihan berhasil")
          ? "LULUS"
          : "GAGAL";
    } catch (err) {
      row.result = "GAGAL";
      row.error = err instanceof Error ? err.message : String(err);
    }
    results.push(row);
    console.log(`${tc.cipher}: ${row.result}${row.error ? ` (${row.error})` : ""}`);
    await context.close();
  }
} finally {
  await browser.close();
}

const out = {
  generatedAt: new Date().toISOString(),
  command: `node ui-file-teks-alfabet.mjs <proyek> <keluaran> ${baseURL}`,
  node: process.version,
  browser: `Chromium ${browserVersion}`,
  expectedPlaintext: expected,
  total: results.length,
  passed: results.filter((r) => r.result === "LULUS").length,
  results,
};
writeFileSync(path.join(outDir, "ui-file-teks-alfabet.json"), `${JSON.stringify(out, null, 2)}\n`);
console.log(`Selesai: ${out.passed}/${out.total} LULUS`);
if (out.passed !== out.total) process.exit(1);
