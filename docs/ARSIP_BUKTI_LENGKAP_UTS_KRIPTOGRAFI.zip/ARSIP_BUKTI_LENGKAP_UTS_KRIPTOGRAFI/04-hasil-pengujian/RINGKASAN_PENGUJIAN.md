# Ringkasan Pengujian

Semua angka pada berkas ini dibaca dari data hasil eksekusi di folder `data`. Pengujian dijalankan pada 1 Oktober 2026 dengan Node.js v24.21.0, pnpm 10.19.0, Python 3.13.13, dan Chromium 153.0.8010.12.

## Ringkasan eksekusi

| Pemeriksaan | Perintah | Hasil |
| --- | --- | --- |
| Versi paket terhadap daftar paket berbahaya | `pnpm check:deps` | 450 paket di lockfile diperiksa terhadap 365 entri daftar, tidak ada versi terlarang |
| Pemeriksaan tipe | `pnpm typecheck` | Lulus tanpa galat |
| Lint | `pnpm lint` | Lulus tanpa galat |
| Pengujian logika | `pnpm test` | 114 dari 114 lulus |
| Skenario bukti | `pnpm evidence` | 42 dari 42 lulus (35 skenario file dan 7 contoh teks) |
| Format file hasil pemulihan | `python scripts/verify_samples.py` | 28 dari 28 lulus |
| Pengujian browser | `pnpm test:e2e` | 26 dari 26 lulus tanpa pengulangan |
| Build produksi | `pnpm build` | Berhasil |
| 35 skenario file melalui antarmuka dengan muat ulang halaman | `node ui-roundtrip-35.mjs` | 35 dari 35 lulus |
| File sebagai teks alfabet melalui antarmuka | `node ui-file-teks-alfabet.mjs` | 5 dari 5 lulus |

Dua baris terakhir adalah uji tambahan untuk bahan laporan. Skripnya disertakan di paket bahan laporan dan memakai Playwright dari proyek terhadap aplikasi hasil build produksi.

Nilai acuan pada pengujian ditulis sebagai literal, bukan dihitung ulang dengan fungsi yang sedang diuji. Checksum pembanding pada skrip bukti dan uji antarmuka dihitung dengan modul `crypto` Node.js, terpisah dari SHA-256 aplikasi.

## Ringkasan per cipher

| Cipher | Vektor acuan dua arah | Contoh teks skrip bukti | Lima file skrip bukti | Alur teks browser | Alur file browser | Lima file antarmuka dengan muat ulang | File sebagai teks alfabet |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Vigenere standar | 2 dari 2 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Lulus |
| Auto-Key Vigenere | 2 dari 2 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Lulus |
| Extended Vigenere | 2 dari 2 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Tidak berlaku |
| Playfair | 3 dari 3 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Lulus |
| Affine | 2 dari 2 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Lulus |
| Hill | 2 dari 2 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Lulus |
| Super Enkripsi | 3 dari 3 | Lulus | 5 dari 5 | Lulus | Lulus | 5 dari 5 | Tidak berlaku |

Lima file adalah teks (`.txt`), gambar (`.png`), database (`.sqlite`), audio (`.wav`), dan video (`.webm`). Kolom terakhir hanya berlaku untuk lima cipher 26 huruf. Rincian tiap skenario, kasus batas, dan pembahasan ada di dokumen `00-BAHAN_LAPORAN_UTS_KRIPTOGRAFI.md` bagian 5 dan 8.

## Berkas data

| Berkas | Dihasilkan oleh | Isi |
| --- | --- | --- |
| `data/unit-test-results.json` | `pnpm test` | Hasil Vitest per tes: vektor acuan dan kasus batas |
| `data/file-scenarios.json` dan `data/file-scenarios.md` | `pnpm evidence` | 35 skenario file dengan kunci uji, ukuran asal, ukuran paket, ukuran payload, ukuran hasil, SHA-256 asal dan hasil, kesamaan byte, dan status header |
| `data/text-examples.json` | `pnpm evidence` | Contoh teks per cipher: pesan, kunci, plainteks yang diproses, cipherteks, Base64, paket Base64, metadata pemulihan, dan hasil dekripsi |
| `data/format-checks.json` | `python scripts/verify_samples.py` | Pemeriksaan format file hasil pemulihan: SQLite, PNG, WAV, dan UTF-8 |
| `data/e2e-results.json` | `pnpm test:e2e` | Hasil Playwright per alur browser |
| `data/ui-roundtrip-35.json` | `skrip/ui-roundtrip-35.mjs` | 35 skenario file melalui antarmuka dengan muat ulang halaman |
| `data/ui-file-teks-alfabet.json` | `skrip/ui-file-teks-alfabet.mjs` | Pilihan Isi sebagai teks alfabet pada lima cipher 26 huruf |
| `log/*.log` | Setiap perintah di atas | Keluaran terminal apa adanya |

Path lokal komputer pada data dan log disamarkan menjadi `<proyek>`, `<keluaran-uji>`, atau `Users/<pengguna>`. Selain itu isi berkas tidak diubah.

Skrip uji tambahan dijalankan terhadap server produksi proyek (`pnpm build` lalu `pnpm start -p 3200 -H 127.0.0.1`) dengan perintah `node ui-roundtrip-35.mjs <folder proyek> <folder keluaran>` dan `node ui-file-teks-alfabet.mjs <folder proyek> <folder keluaran>`. Kedua skrip memakai Playwright yang sudah terpasang di proyek.
