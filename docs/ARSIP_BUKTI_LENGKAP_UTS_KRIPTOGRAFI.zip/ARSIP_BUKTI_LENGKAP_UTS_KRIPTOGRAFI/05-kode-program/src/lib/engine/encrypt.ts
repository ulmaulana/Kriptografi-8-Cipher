// Jalur enkripsi yang dipakai UI (melalui Web Worker), pengujian, dan skrip bukti.

import { alpha25Encode } from "../codecs/alpha25";
import { indicesToAscii, lettersToIndices, normalizeAlphabetic, normalizeAlphabeticBytes } from "../codecs/alphabet";
import { encodeBase64 } from "../codecs/base64";
import { encodeUtf8 } from "../codecs/utf8";
import { sha256Hex } from "../container/checksum";
import { serializeContainer } from "../container/format";
import { type ContainerMetadata, expectedCodec, type InputMode, sanitizeFileName } from "../container/metadata";
import { isAlphaCipher } from "../crypto/ciphers";
import { UserFacingError } from "../crypto/errors";
import { parseKeyOrThrow } from "../validation/keys";
import { encryptBytes, encryptLetters } from "./letters";
import type { EncryptRequest, EncryptResult } from "./types";

export const MAX_FILE_BYTES = 50 * 1024 * 1024;

export async function encryptMessage(request: EncryptRequest): Promise<EncryptResult> {
  const { cipher, input } = request;
  const { key, notes } = parseKeyOrThrow(cipher, request.key);
  const alpha = isAlphaCipher(cipher);

  if (input.kind === "file" && input.bytes.length > MAX_FILE_BYTES) {
    throw new UserFacingError(
      `Ukuran file ${input.bytes.length} byte melebihi batas implementasi ${MAX_FILE_BYTES} byte (50 MB).`,
      "file",
    );
  }

  let inputMode: InputMode;
  let plainBytes: Uint8Array;
  let payload: Uint8Array;
  const details: string[] = [];
  let playfairMeta: ContainerMetadata["playfair"];
  let hillMeta: ContainerMetadata["hill"];

  if (alpha) {
    let letters: Uint8Array;
    if (input.kind === "text") {
      inputMode = "text";
      const normalized = normalizeAlphabetic(input.text);
      if (normalized.length === 0) {
        throw new UserFacingError(
          input.text.length === 0 ? "Pesan wajib diisi." : "Pesan tidak menyisakan huruf A-Z setelah normalisasi.",
          "message",
        );
      }
      letters = lettersToIndices(normalized);
      plainBytes = indicesToAscii(letters);
    } else if (input.readAs === "alpha-text") {
      inputMode = "text";
      // Byte ASCII huruf pada UTF-8 tidak pernah menjadi bagian karakter multibyte,
      // sehingga penyaringan byte setara dengan mendekode UTF-8 lalu menyaring huruf.
      letters = normalizeAlphabeticBytes(input.bytes);
      if (letters.length === 0) throw new UserFacingError("Isi file tidak menyisakan huruf A-Z setelah normalisasi.", "file");
      plainBytes = indicesToAscii(letters);
    } else {
      inputMode = "file";
      plainBytes = input.bytes;
      letters = alpha25Encode(input.bytes);
      details.push(`Codec alpha25-v1: ${input.bytes.length} byte menjadi ${letters.length} huruf sebelum cipher.`);
    }
    const out = encryptLetters(key, letters);
    details.push(...out.details);
    payload = indicesToAscii(out.cipher);
    if (out.playfair) {
      playfairMeta = {
        markers: "bitset-lsb-v1",
        filler: encodeBase64(out.playfair.fillerBits),
        fillerCount: out.playfair.fillerCount,
        jCount: out.playfair.jCount,
      };
      if (inputMode === "text") playfairMeta.j = encodeBase64(out.playfair.jBits);
    }
    if (out.hill) hillMeta = out.hill;
  } else {
    if (input.kind === "text") {
      if (input.text.length === 0) throw new UserFacingError("Pesan wajib diisi.", "message");
      inputMode = "text";
      plainBytes = encodeUtf8(input.text);
    } else {
      inputMode = "file";
      plainBytes = input.bytes;
    }
    payload = encryptBytes(key, plainBytes);
  }

  const metadata: ContainerMetadata = {
    algorithm: cipher,
    inputMode,
    codec: expectedCodec(cipher, inputMode),
    payloadEncoding: alpha ? "ascii-letters" : "bytes",
    payloadLength: payload.length,
    expectedLength: plainBytes.length,
    checksumAlgorithm: "SHA-256",
    sha256: await sha256Hex(plainBytes),
  };
  if (input.kind === "file") {
    if (inputMode === "file") metadata.file = { name: sanitizeFileName(input.name), type: input.type };
    else metadata.sourceFileName = sanitizeFileName(input.name);
  }
  if (playfairMeta) metadata.playfair = playfairMeta;
  if (hillMeta) metadata.hill = hillMeta;

  return {
    cipher,
    inputMode,
    plainBytes,
    payload,
    container: serializeContainer(metadata, payload),
    metadata,
    keyNotes: notes,
    details,
  };
}
