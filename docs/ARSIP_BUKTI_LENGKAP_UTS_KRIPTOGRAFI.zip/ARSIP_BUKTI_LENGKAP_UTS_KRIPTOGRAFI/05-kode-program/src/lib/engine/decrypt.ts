// Jalur dekripsi: paket .dat (dengan metadata pemulihan), cipherteks alfabet
// mentah, dan Base64 payload. Algoritma dan mode paket diambil dari metadata
// sehingga dekripsi tidak bergantung pada state enkripsi sebelumnya.

import { alpha25Decode, CodecError } from "../codecs/alpha25";
import { indicesToAscii, lettersToIndices, normalizeAlphabetic, normalizeAlphabeticBytes, strictAsciiToIndices } from "../codecs/alphabet";
import { Base64Error, decodeBase64 } from "../codecs/base64";
import { decodeUtf8Strict } from "../codecs/utf8";
import { sha256Hex } from "../container/checksum";
import { parseContainer } from "../container/format";
import { ContainerError } from "../container/metadata";
import { type CipherId, isAlphaCipher } from "../crypto/ciphers";
import { UserFacingError } from "../crypto/errors";
import { parseKeyOrThrow } from "../validation/keys";
import { decryptBytes, decryptLettersPackage, decryptLettersRaw } from "./letters";
import type { DecryptRequest, DecryptResult, PackageSummary } from "./types";

export function inspectPackage(container: Uint8Array): PackageSummary {
  const { metadata } = parseContainer(container);
  return {
    algorithm: metadata.algorithm,
    inputMode: metadata.inputMode,
    codec: metadata.codec,
    payloadLength: metadata.payloadLength,
    expectedLength: metadata.expectedLength,
    fileName: metadata.file?.name ?? null,
    fileType: metadata.file?.type ?? null,
    sourceFileName: metadata.sourceFileName ?? null,
  };
}

const CHECK_KEY_HINT = "Kemungkinan kunci salah atau data paket rusak.";

async function decryptPackage(container: Uint8Array, keyValues: DecryptRequest["key"]): Promise<DecryptResult> {
  const parsed = parseContainer(container);
  const { metadata, payload } = parsed;
  const { key, notes } = parseKeyOrThrow(metadata.algorithm, keyValues);
  const details: string[] = [];

  let bytes: Uint8Array;
  if (isAlphaCipher(metadata.algorithm)) {
    const cipherLetters = strictAsciiToIndices(payload);
    if (!cipherLetters) throw new ContainerError("Payload cipher alfabet berisi karakter selain A-Z.");
    if (key.cipher === "hill" && metadata.hill && key.matrix.length !== metadata.hill.n) {
      throw new UserFacingError(
        `Paket dibuat dengan matriks ${metadata.hill.n} x ${metadata.hill.n}, sedangkan kunci berukuran ${key.matrix.length} x ${key.matrix.length}.`,
        "hillMatrix",
      );
    }
    const letters = decryptLettersPackage(key, cipherLetters, {
      playfairBits: parsed.playfairBits,
      hillPadCount: metadata.hill?.padCount,
    });
    if (metadata.playfair) details.push(`Pengisi dibuang sesuai metadata: ${metadata.playfair.fillerCount}. J dipulihkan: ${metadata.playfair.jCount}.`);
    if (metadata.hill) details.push(`Padding X dibuang sesuai metadata: ${metadata.hill.padCount}.`);
    if (metadata.codec === "alpha25-v1") {
      try {
        bytes = alpha25Decode(letters);
      } catch (err) {
        if (err instanceof CodecError) {
          throw new UserFacingError(
            `Dekripsi gagal: hasil tidak dapat dikembalikan menjadi byte file. ${CHECK_KEY_HINT} (Detail: ${err.message})`,
            "key",
          );
        }
        throw err;
      }
      details.push(`Codec alpha25-v1: ${letters.length} huruf dikembalikan menjadi ${bytes.length} byte.`);
    } else {
      bytes = indicesToAscii(letters);
    }
  } else {
    bytes = decryptBytes(key, payload);
  }

  if (bytes.length !== metadata.expectedLength) {
    throw new UserFacingError(
      `Ukuran hasil ${bytes.length} byte tidak sama dengan ukuran yang diharapkan ${metadata.expectedLength} byte. ${CHECK_KEY_HINT}`,
      "key",
    );
  }
  const sha256 = await sha256Hex(bytes);
  if (sha256 !== metadata.sha256) {
    throw new UserFacingError(
      `Checksum SHA-256 hasil dekripsi tidak cocok dengan paket sehingga pemulihan tidak dinyatakan berhasil. ${CHECK_KEY_HINT}`,
      "key",
    );
  }

  let representation: DecryptResult["representation"];
  if (metadata.inputMode === "file") representation = "binary";
  else if (isAlphaCipher(metadata.algorithm)) representation = "letters";
  else representation = "utf8";

  return {
    cipher: metadata.algorithm,
    source: "package",
    inputMode: metadata.inputMode,
    representation,
    bytes,
    payload,
    verified: true,
    sha256,
    expectedSha256: metadata.sha256,
    fileName: metadata.file?.name ?? null,
    fileType: metadata.file?.type ?? null,
    keyNotes: notes,
    details,
  };
}

async function decryptRaw(
  cipher: CipherId,
  payload: Uint8Array,
  source: "raw-letters" | "payload-base64",
  keyValues: DecryptRequest["key"],
  cipherLetters: Uint8Array | null,
): Promise<DecryptResult> {
  const { key, notes } = parseKeyOrThrow(cipher, keyValues);
  const details: string[] = [];
  let bytes: Uint8Array;
  let representation: DecryptResult["representation"];
  if (isAlphaCipher(cipher)) {
    if (!cipherLetters || cipherLetters.length === 0) {
      throw new UserFacingError("Cipherteks tidak berisi huruf A-Z.", "cipherInput");
    }
    bytes = indicesToAscii(decryptLettersRaw(key, cipherLetters));
    representation = "letters";
    if (cipher === "playfair") details.push("Tanpa metadata, huruf pengisi dan I hasil penggabungan J tetap ada pada hasil.");
    if (cipher === "hill") details.push("Tanpa metadata, padding X di akhir tetap ada pada hasil.");
  } else {
    bytes = decryptBytes(key, payload);
    representation = decodeUtf8Strict(bytes) === null ? "binary" : "utf8";
  }
  details.push("Jalur mentah tidak memiliki checksum sehingga kunci salah tidak selalu dapat dikenali.");
  return {
    cipher,
    source,
    inputMode: "raw",
    representation,
    bytes,
    payload,
    verified: false,
    sha256: await sha256Hex(bytes),
    expectedSha256: null,
    fileName: null,
    fileType: null,
    keyNotes: notes,
    details,
  };
}

export async function decryptMessage(request: DecryptRequest): Promise<DecryptResult> {
  switch (request.kind) {
    case "package":
      return decryptPackage(request.container, request.key);
    case "raw-letters": {
      if (!isAlphaCipher(request.cipher)) {
        throw new UserFacingError("Cipherteks alfabet mentah hanya untuk lima cipher alfabet.", "cipherInput");
      }
      const normalized = normalizeAlphabetic(request.text);
      const letters = lettersToIndices(normalized);
      return decryptRaw(request.cipher, indicesToAscii(letters), "raw-letters", request.key, letters);
    }
    case "payload-base64": {
      let payload: Uint8Array;
      try {
        payload = decodeBase64(request.base64);
      } catch (err) {
        if (err instanceof Base64Error) throw new UserFacingError(err.message, "cipherInput");
        throw err;
      }
      if (payload.length === 0 && isAlphaCipher(request.cipher)) {
        throw new UserFacingError("Base64 payload kosong.", "cipherInput");
      }
      // Normalisasi huruf hanya dijalankan setelah Base64 didekode menjadi byte payload.
      const letters = isAlphaCipher(request.cipher) ? normalizeAlphabeticBytes(payload) : null;
      return decryptRaw(request.cipher, payload, "payload-base64", request.key, letters);
    }
  }
}
